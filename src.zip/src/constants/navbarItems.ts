export const NAV_ITEMS = [
    { id: "servicios", label: "Servicios" },
    { id: "nosotros", label: "Nosotros" },
    { id: "testimonials", label: "Testimonios" },
    { id: "preguntas", label: "Preguntas frecuentes" },
] as const;
