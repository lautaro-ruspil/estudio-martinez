export const testimonials = [
    {
        id: 1,
        name: "María González",
        business: "Panadería Don José",
        content:
            "Hace 5 años que trabajo con Roberto. Me saca de todos los líos con AFIP y siempre me explica todo claro. Lo recomiendo 100%.",
        rating: 5,
    },
    {
        id: 2,
        name: "Carlos Ramírez",
        business: "Ferretería Central",
        content:
            "Excelente atención. Me ayudó a pasar de monotributo a responsable inscripto sin complicaciones. Muy profesional.",
        rating: 5,
    },
    {
        id: 3,
        name: "Laura Fernández",
        business: "Emprendedora",
        content:
            "Arranqué con mi emprendimiento y no sabía nada de impuestos. Me explicó todo paso a paso. Super recomendable.",
        rating: 5,
    },
];
